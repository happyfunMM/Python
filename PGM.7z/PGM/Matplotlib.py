# -*- coding: utf-8 -*-
"""
Created on Wed May 27 15:44:55 2020

@author: Daisy Chan
"""

from matplotlib import pyplot as plt
import pandas as pd
import numpy as np
df = pd.read_csv(r'G:\Personal\My_Python\DataSet\Provisional_COVID-19_Death_Counts_by_Place_of_Death_and_State.csv')

import urllib
url = 'https://data.cityofchicago.org/api/views/ijzp-q8t2/rows.csv'  
urllib.request.urlretrieve(url, "F:\Personal\My_Python\DataSet\Crime_2010_to_present.csv")
df_2 = pd.read_csv('F:\Personal\My_Python\DataSet\Crime_2010_to_present.csv')

# =============================================================================
# Introduction
# =============================================================================
# Matplotlib graphs your data on Figures (i.e., windows, Jupyter widgets, etc.), 
# each of which can contain one or more Axes 
# (i.e., an area where points can be specified in terms of x-y coordinates 
# (or theta-r in a polar plot, or x-y-z in a 3D plot, etc.). 
# The most simple way of creating a figure with an axes is using pyplot.subplots.
# We can then use Axes.plot to draw some data on the axes:
fig, ax = plt.subplots()
# ax.plot()
# plt.plot(df['COVID19 Deaths'])
x = range(10)
x = np.array(x)
y1 = 3*x -10
y2 = x**2
y3 = x**3

# Figure: The figure keeps track of all the child Axes, 
# a smattering of 'special' artists (titles, figure legends, etc), 
# and the canvas. (Don't worry too much about the canvas, it is crucial 
# as it is the object that actually does the drawing to get you your plot, 
# but as the user it is more-or-less invisible to you). 
# A figure can contain any number of Axes, but will typically have at least one.

# Axes: This is what you think of as 'a plot', it is the region of the image 
# with the data space. A given figure can contain many Axes, but a given Axes object 
# can only be in one Figure. The Axes contains two (or three in the case of 3D) 
# Axis objects (be aware of the difference between Axes and Axis) which 
# take care of the data limits (the data limits can also be controlled via 
# the axes.Axes.set_xlim() and axes.Axes.set_ylim() methods). 
# Each Axes has a title (set via set_title()), an x-label (set via set_xlabel()), 
# and a y-label set via set_ylabel()).

# Axis: These are the number-line-like objects. They take care of setting the 
# graph limits and generating the ticks (the marks on the axis) and ticklabels
# (strings labeling the ticks). The location of the ticks is determined by 
# a Locator object and the ticklabel strings are formatted by a Formatter. 
# The combination of the correct Locator and Formatter gives very fine control 
# over the tick locations and labels.

# Artist: Basically everything you can see on the figure is an artist 
# (even the Figure, Axes, and Axis objects). This includes Text objects,
# Line2D objects, collections objects, Patch objects ... (you get the idea). 
# When the figure is rendered, all of the artists are drawn to the canvas. 
# Most Artists are tied to an Axes; such an Artist cannot be shared by 
# multiple Axes, or moved from one to another.

# =============================================================================
# The object-oriented interface and the pyplot interface:
#
# 1. Explicitly create figures and axes, and call methods on them (the "object-oriented (OO) style").
# 2. Rely on pyplot to automatically create and manage the figures and axes, 
# and use pyplot functions for plotting.
# =============================================================================
fig, ax = plt.subplots()
ax.plot(x, y1, label='linear')  # Plot some data on the axes.
ax.plot(x, y2, label='quadratic')  # Plot more data on the axes...
ax.plot(x, y3, label='cubic')  # ... and some more.
ax.set_xlabel('x label')  # Add an x-label to the axes.
ax.set_ylabel('y label')  # Add a y-label to the axes.
ax.set_title("Simple Plot")  # Add a title to the axes.
ax.legend()  # Add a legend.


plt.plot(x, y1, label = 'Linear')
plt.plot(x, y2, label = 'quadratic')
plt.plot(x, y3, label = 'cubic')
plt.xlabel( 'x label')
plt.ylabel('y label')
plt.title('simple plot')
plt.legend()
plt.show()


# Matplotlib's documentation and examples use both the OO and the pyplot approaches 
# (which are equally powerful), and you should feel free to use either
# (however, it is preferable pick one of them and stick to it, instead of mixing them). 
# In general, we suggest to restrict pyplot to interactive plotting 
# (e.g., in a Jupyter notebook), and to prefer the OO-style for non-interactive plotting 
# (in functions and scripts that are intended to be reused as part of a larger project).

# Plotting with categorical variables
# Working with multiple figures and axes
plt.subplot(221)
ss = df.groupby('State').sum()
ss = ss.reset_index(drop = False)
plt.bar(ss['State'], ss['COVID19 Deaths'])
plt.xticks(rotation = -60)
plt.subplot(222)
plt.scatter(ss['State'], ss['COVID19 Deaths'], color = 'y')
plt.xticks(rotation = -60)
plt.suptitle('Categorical Plotting')
plt.show()

# hist plot
import numpy as np
x = 80 + 2*np.random.randn(1000)
plt.hist(ss['State'],bins=30)
plt.text(74, 20, 'xxxxx')
#plt.axis([min(x)-1, max(x)+1, 0, 250])
# plt.grid(True)







