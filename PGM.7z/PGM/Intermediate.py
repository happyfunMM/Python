# -*- coding: utf-8 -*-
"""
Created on Mon May 25 17:04:54 2020

@author: Daisy Chan
"""

# 迭代是重复反馈过程的活动，其目的通常是为了逼近所需目标或结果。
# 每一次对过程的重复称为一次“迭代”，而每一次迭代得到的结果会作为下一次迭代的初始值。

# =============================================================================
# Iterable & Iterator
#
# Iteration is a general term for taking each item of something, one after another. 
# Any time you use a loop, explicit or implicit, to go over a group of items, 
# that is iteration.
# 
# In Python, iterable and iterator have specific meanings.
# An iterable is an object that has an __iter__ method which returns an iterator, 
# or which defines a __getitem__ method that can take sequential indexes starting 
# from zero (and raises an IndexError when the indexes are no longer valid). 
# So an iterable is an object that you can get an iterator from.
# 
# An iterator is an object with a __next__ (Python 3) method.
# Whenever you use a for loop, or map, or a list comprehension, etc. 
# in Python, the next method is called automatically to get each item from the iterator, 
# thus going through the process of iteration.
#
# The iterator protocol is used to define a standard way that an object produces a sequence of values. 
# What that really means is you now have a process for defining how an object will iterate. 
# This is done through implementing the .next()method.
#
# An object becomes an iterator when it implements the .next() method. 
# The .next() method is a zero arguments function that returns an object with two properties:
#
# 1. value : the data representing the next value in the sequence of values within the object
# 2. done : a boolean representing if the iterator is done going through the sequence of values
#
# If done is true, then the iterator has reached the end of its sequence of values.
# If done is false, then the iterator is able to produce another value in its sequence of values.
# =============================================================================
# =============================================================================
# PyObject *iterator = PyObject_GetIter(obj);
# PyObject *item;
# 
# if (iterator == NULL) {
#     /* propagate error */
# }
# 
# while ((item = PyIter_Next(iterator))) {
#     /* do something with item */
#     ...
#     /* release reference when done */
#     Py_DECREF(item);
# }
# 
# Py_DECREF(iterator);
# 
# if (PyErr_Occurred()) {
#     /* propagate error */
# }
# else {
#     /* continue doing useful work */
# }
# =============================================================================
# Iterator & Interable
# a list is a interable
ls = [1,2,3,4,5,6,7,8,9,0]

# will return number 2
ls.__getitem__(1)

# create an interator, by using iter()
its = iter(ls)

# iterators have method __next__()
print(its.__next())

# do it time and time again, what will happen?
print(its.__next())
# will get  'StopIteration'
    

# =============================================================================
# Python OOP: Object oriented Programming
# Python is a multi-paradigm programming language. Meaning, it supports different programming approach.
# One of the popular approach to solve a programming problem is by creating objects. 
# This is known as Object-Oriented Programming (OOP).
# 
# An object has two characteristics:
# 
# 1. attributes
# 2. behavior
#
# The concept of OOP in Python focuses on creating reusable code. 
# This concept is also known as DRY (Don't Repeat Yourself).                                  
# In Python, the concept of OOP follows some basic principles:
#
# Inheritance: A process of using details from a new class without modifying existing class.
# Encapsulation: Hiding the private details of a class from other objects.
# Polymorphism: A concept of using common operation in different ways for different data input.
# =============================================================================
# Class
# A class is a blueprint for the object.

# We can think of class as an sketch of a parrot with labels. 
# It contains all the details about the name, colors, size etc. Based on these descriptions, 
# we can study about the parrot. Here, parrot is an object.
class Parrot:
    pass

# A class creates a new local namespace where all its attributes are defined. 
# Attributes may be data or functions.
#
# There are also special attributes in it that begins with double underscores (__).
# For example, __doc__ gives us the docstring of that class.
class Parrot:

    '''class attribute'''
    species = "bird"
    ''' instance attribute'''
    def __init__(self, name, age):
        self.name = name
        self.age = age

# output: class attribute 
print(Parrot.__doc__) 

# As soon as we define a class, a new class object is created with the same name. 
# This class object allows us to access the different attributes as well as 
# to instantiate new objects of that class.
#
# An object (instance) is an instantiation of a class. When class is defined, 
# only the description for the object is defined. Therefore, 
# no memory or storage is allocated.
# The example for object of parrot class can be:
obj = Parrot('John', 2)
# You may have noticed the self parameter in function definition inside the class but, 
# we called the method simply as ob.func() without any arguments. It still worked.
# This is because, whenever an object calls its method, the object itself is 
# passed as the first argument. So, ob.func() translates into MyClass.func(ob).
# In general, calling a method with a list of n arguments is equivalent to calling 
# the corresponding function with an argument list that is created by inserting 
# the method's object before the first argument.
# For these reasons, the first argument of the function in class must be the object itself. 
# This is conventionally called self. It can be named otherwise but we highly 
# recommend to follow the convention.

# Methods are functions defined inside the body of a class. 
# They are used to define the behaviors of an object.
# Create Class within attribute 'species'
# The attributes are a characteristic of an object.
class Parrot:

    '''class attribute'''
    species = "bird"
    ''' instance attribute'''
    def __init__(self, name, age):
        self.name = name
        self.age = age
    def func(self):
        print("The parrot's name is %s, it is %d years old." % (self.name, self.age))

# In the above program, we define A methods i.e func(). 
# It is called instance method because they are called on an instance object i.e Parrot.
obj2 = Parrot('John', 2)
obj2.func()

# Inheritance
# Inheritance is a way of creating new class for using details of existing class 
# without modifying it. The newly formed class is a derived class (or child class). 
# Similarly, the existing class is a base class (or parent class).
# 以双下划线开头，双下划线结尾： 内置属性名或者魔法方法名 
# parent class
class Bird:
    
    def __init__(self):
        print("Bird is ready")

    def whoisThis(self):
        print("Bird")

    def swim(self):
        print("Swim faster")

# child class
class Penguin(Bird):

    def __init__(self):
        # call super() function
        super().__init__()
        print("Penguin is ready")

    def whoisThis(self):
        print("Penguin")

    def run(self):
        print("Run faster")

peggy = Penguin()
peggy.whoisThis()
peggy.swim()
peggy.run()
# In the above program, we created two classes i.e. 
# Bird (parent class) and Penguin (child class). The child class inherits the 
# functions of parent class. We can see this from swim() method. 
# Again, the child class modified the behavior of parent class.
# We can see this from whoisThis() method. Furthermore, we extend the functions 
# of parent class, by creating a new run() method.

# Encapsulation
# Using OOP in Python, we can restrict access to methods and variables. 
# This prevent data from direct modification which is called encapsulation. 
# In Python, we denote private attribute using underscore as prefix i.e 
# single “ _ “ or double “ __“.
# doc: "My_python/Doc/Python 面向对象编程OOP (一) 类，对象，属性，访问权限 - 阿尔法的Python笔记 - SegmentFault 思否.pdf"
class Car:
    wheels = 0
    def __init__(self, color, model, year):
        self.color = color
        self.model = model
        self.year = year
        self._holder = 5
first_car = Car('red', 'Bee', 1961)
#second_car = Car('yellow', 'Big Bee', 1969)
print(first_car._holder)

class Car:
    wheels = 0
    def __init__(self, color, model, year):
        self.color = color
        self.model = model
        self.year = year
        self._holder = 5
        self.__host = 'D'
first_car = Car('red', 'Bee', 1961)
'''AttributeError: 'Car' object has no attribute 'Car___hoder''''
print(first_car.__holder) 
# Add _ClassName prefix
print(first_car._Car__host)


# Polymorphism
# Polymorphism is an ability (in OOP) to use common interface for multiple form (data types).
# Suppose, we need to color a shape, there are multiple shape option 
# (rectangle, square, circle). However we could use same method to color any shape. 
# This concept is called Polymorphism.
class Parrot:

    def fly(self):
        print("Parrot can fly")
    
    def swim(self):
        print("Parrot can't swim")

class Penguin:

    def fly(self):
        print("Penguin can't fly")
    
    def swim(self):
        print("Penguin can swim")

# common interface
def flying_test(bird):
    bird.fly()

#instantiate objects
blu = Parrot()
peggy = Penguin()

# passing the object
flying_test(blu)
flying_test(peggy)

# In the above program, we defined two classes Parrot and Penguin. 
# Each of them have common method fly() method. However, their functions are different. 
# To allow polymorphism, we created common interface i.e flying_test() function that can take any object. 
# Then, we passed the objects blu and peggy in the flying_test() function, it ran effectively.

# =============================================================================
# *arg is ALWAYS IN THE FRONT OF **kwargs 
# =============================================================================
# arg: arguments 
# *arg in python is used to pass a variable number of arguments to a function(even none arg)
# kwargs: key words arguments 
#  **kwargs is a dictionary of keyword arguments. The ** allows us to pass any number of keyword arguments. 



# read a batch of files
a_batch_of_file_names = [file name list]
#Initialize an empyy list: medals
last_list_of_file =[]

for file in a_batch_of_file_names:
    # Create the file name: file_name
    file_name = "%s_balabalabala.csv" % file
    # Create list of column names: columns
    columns = ['col_name_1', 'col_name_2']
    # Read file_name into a DataFrame: file_df
    file_df = pd.read_csv(file_name, header = 0, index_col = 'colum_name_0', names =columns)
    # Append file_df to last_list_of_file
    last_list_of_file.append(file_df)

# Concatenate files horizontally: file_df_final
file_df_final = pd.concat(last_list_of_file, axis = 'columns')

# Print file_df_final
print(file_df_final)





