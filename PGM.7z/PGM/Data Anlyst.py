# -*- coding: utf-8 -*-
"""
Created on Fri Jul 24 11:22:54 2020

@author: Daisy Chan
"""

# =============================================================================
# Data Analyst:
#     0. import data/export data
#     1. check missing value
#     2. check duplicated value
#     3. sort values
#     4. select specified row/column
#     5. join tables
#     6. create new columns/rows
#     7. split tables
#     8. delete rows/columns/tables
#     9. statistical compute
#     10. plot 
#     11. modeling
#     12. optimal 
#     13. report generation
# =============================================================================
    