# -*- coding: utf-8 -*-
"""
Created on Wed Jul  8 10:10:08 2020

@author: Daisy Chan
"""


# =============================================================================
# Supervised Learning with scikit-learn
# =============================================================================
from sklearn import datasets
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
plt.style.use('ggplot')
iris = datasets.load_iris()
type(iris)
# sklearn.utils.Bunch
# Bunch本质上的数据类型是dict，属性有：
# data：数据数组
# target：文件分类。如猫狗两类的话，与filenames一一对应为0或1
# target_names：标签名。可自定义，默认为文件夹名
# DESCR：数据描述
# filenames：文件名



# Model: Classification
# =============================================================================
# k-Nearest Neighbors
# =============================================================================
from sklearn.neighbors import KNeighborsClassifier 

# Create arrays for the features and the response variable
# Note the use of .drop() to drop the target variable 'party' from the feature array 
# X as well as the use of the .values attribute to ensure X and y are NumPy arraysy = df['party'].values
X = df.drop('party', axis=1).values

# Create a k-NN classifier with 6 neighbors
knn = KNeighborsClassifier(n_neighbors=6)

# Fit the classifier to the data
knn.fit(X, y)

# Predict the labels for the training data X
y_pred = knn.predict(X)

# Predict and print the label for the new data point X_new
new_prediction = knn.predict(X_new)
print("Prediction: {}".format(new_prediction))

# =============================================================================
# The digits recognition dataset
# =============================================================================
from sklearn.neighbors import KNeighborsClassifier 
# Import necessary modules
from sklearn import datasets
import matplotlib.pyplot as plt

# Load the digits dataset: digits
digits = datasets.load_digits()
# Each sample in this scikit-learn dataset is an 8x8 image representing a handwritten digit. 
# Each pixel is represented by an integer in the range 0 to 16, 
# indicating varying levels of black. 
# Recall that scikit-learn's built-in datasets are of type Bunch, 
# which are dictionary-like objects. Helpfully for the MNIST dataset, 
# scikit-learn provides an 'images' key in addition to the 'data' and 'target' keys that 
# you have seen with the Iris data. Because it is a 2D array of the images corresponding to 
# each sample, this 'images' key is useful for visualizing the images, 
# as you'll see in this exercise (for more on plotting 2D arrays, 
# see Chapter 2 of DataCamp's course on Data Visualization with Python). 
# On the other hand, the 'data' key contains the feature array - that is, 
# the images as a flattened array of 64 pixels.

# Print the keys and DESCR of the dataset
print(digits.keys())
print(digits.DESCR)

# Print the shape of the images and data keys
print(digits.images.shape)
print(digits.data.shape)

# Display digit 1010
plt.imshow(digits.images[1010], cmap=plt.cm.gray_r, interpolation='nearest')
plt.show()

# Create feature and target arrays
X = digits.data
y = digits.target

# Split into training and test set
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state=42, stratify=y)

# Create a k-NN classifier with 7 neighbors: knn
knn = KNeighborsClassifier(n_neighbors = 7)

# Fit the classifier to the training data
knn.fit(X_train, y_train)

# Print the accuracy
print(knn.score(X_test, y_test))

# Prediction
y_pred = knn.predict(X_test)

# =============================================================================
# Metrics for classification
# =============================================================================
# Import necessary modules
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_recall_fscore_support
# Generate the confusion matrix and classification report
print(classification_report(y_test, y_pred))
print(confusion_matrix(y_test, y_pred))

# =============================================================================
# Hyperparameter tuning with GridSearchCV
# =============================================================================
# Hugo demonstrated how to tune the n_neighbors parameter of the KNeighborsClassifier() 
# using GridSearchCV on the voting dataset. 
from sklearn.model_selection import GridSearchCV
c_space = np.linspace(1, 10, 10)
param_grid = {'C': c_space}
# Instantiate a logistic regression classifier: logreg
logreg = LogisticRegression()

# Instantiate the GridSearchCV object: logreg_cv
logreg_cv = GridSearchCV(logreg, param_grid, cv=5)

# Fit it to the data
logreg_cv.fit(X, y)

# Print the tuned parameters and score
print("Tuned Logistic Regression Parameters: {}".format(logreg_cv.best_params_)) 
print("Best score is {}".format(logreg_cv.best_score_))

# =============================================================================
# Hyperparameter tuning with RandomizedSearchCV
# =============================================================================
# GridSearchCV can be computationally expensive, especially if you are searching over 
# a large hyperparameter space and dealing with multiple hyperparameters. 
# A solution to this is to use RandomizedSearchCV, in which not all hyperparameter values 
# are tried out. Instead, a fixed number of hyperparameter settings is sampled from 
# specified probability distributions.

# Import necessary modules
from scipy.stats import randint
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import RandomizedSearchCV

# Setup the parameters and distributions to sample from: param_dist
param_dist = {"max_depth": [3, None],
              "max_features": randint(1, 9),
              "min_samples_leaf": randint(1, 9),
              "criterion": ["gini", "entropy"]}

# Instantiate a Decision Tree classifier: tree
tree = DecisionTreeClassifier()

# Instantiate the RandomizedSearchCV object: tree_cv
tree_cv = RandomizedSearchCV(tree, param_dist, cv=5)

# Fit it to the data

tree_cv.fit(X, y)
# Print the tuned parameters and score
print("Tuned Decision Tree Parameters: {}".format(tree_cv.best_params_))
print("Best score is {}".format(tree_cv.best_score_))


# =============================================================================
# Building a logistic regression model
# =============================================================================
# Import the necessary modules
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix

# Create training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.4, random_state=42)

# Create the classifier: logreg
logreg = LogisticRegression()

# Fit the classifier to the training data
logreg.fit(X_train, y_train)

# Predict the labels of the test set: y_pred
y_pred = logreg.predict(X_test)

# Compute and print the confusion matrix and classification report
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))

# =============================================================================
# 5-fold cross-validation
# K-Fold CV comparison
# =============================================================================
from sklearn.model_selection import cross_val_score

# Print the 5-fold cross-validation scores
cv_scores = cross_val_score(logreg, X, y, cv = 5, scoring = 'roc_auc')
print(cv_scores)
print("Average 5-Fold CV Score: {}".format(np.mean(cv_scores)))

# =============================================================================
# Plotting an ROC curve
# =============================================================================

# Import necessary modules
from sklearn.metrics import roc_curve 

# Compute predicted probabilities: y_pred_prob
y_pred_prob = logreg.predict_proba(X_test)[:, 1]

# Generate ROC curve values: fpr, tpr, thresholds
# multiclass format is not supported, here should be a 0-1 problem
fpr, tpr, thresholds = roc_curve(y_test, y_pred_prob)

# Plot ROC curve
plt.plot([0, 1], [0, 1], 'k--')
plt.plot(fpr, tpr)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.show()

# =============================================================================
# AUC computation
# =============================================================================
# Import necessary modules
from sklearn.metrics import roc_auc_score 
from sklearn.model_selection import cross_val_score

# Compute predicted probabilities: y_pred_prob
y_pred_prob = logreg.predict_proba(X_test)[:,1]

# Compute and print AUC score
print("AUC: {}".format(roc_auc_score(y_test, y_pred_prob)))

# Compute cross-validated AUC scores: cv_auc
cv_auc = cross_val_score(logreg, X, y, cv = 5, scoring = 'roc_auc')

# Print list of AUC scores
print("AUC scores computed using 5-fold cross-validation: {}".format(cv_auc))

# =============================================================================
# Overfitting and underfitting
# # Setup arrays to store train and test accuracies
# neighbors = np.arange(1, 9)
# train_accuracy = np.empty(len(neighbors))
# test_accuracy = np.empty(len(neighbors))
# 
# # Loop over different values of k
# for i, k in enumerate(neighbors):
#     # Setup a k-NN Classifier with k neighbors: knn
#     knn = KNeighborsClassifier(n_neighbors=k)
# 
#     # Fit the classifier to the training data
#     knn.fit(X_train, y_train)
#     
#     #Compute accuracy on the training set
#     train_accuracy[i] = knn.score(X_train, y_train)
# 
#     #Compute accuracy on the testing set
#     test_accuracy[i] = knn.score(X_test, y_test)
# 
# # Generate plot
# plt.title('k-NN: Varying Number of Neighbors')
# plt.plot(neighbors, test_accuracy, label = 'Testing Accuracy')
# plt.plot(neighbors, train_accuracy, label = 'Training Accuracy')
# plt.legend()
# plt.xlabel('Number of Neighbors')
# plt.ylabel('Accuracy')
# plt.show()
# =============================================================================
import numpy as np
linnerud = datasets.load_linnerud()
X = linnerud.data
y = linnerud.target
col = linnerud.feature_names
target = linnerud.target_names
# Regression Model
# Import LinearRegression
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split

# Create training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y[:,0], test_size = 0.3, random_state=42)

# Create the regressor: reg
reg = LinearRegression()

# Fit the regressor to the training data
reg.fit(X_train, y_train)

# Predict on the test data: y_pred
y_pred = reg.predict(X_test)

# Compute and print R^2 and RMSE
print("R^2: {}".format(reg.score(X_test, y_test)))
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print("Root Mean Squared Error: {}".format(rmse))

# =============================================================================
# Regularization I: Lasso
# =============================================================================
# Import Lasso
from sklearn.linear_model import Lasso

# Instantiate a lasso regressor: lasso
lasso = Lasso(alpha = 0.4, normalize = True)

# Fit the regressor to the data
lasso.fit(X, y)

# Compute and print the coefficients
lasso_coef = lasso.coef_
print(lasso_coef)

# Plot the coefficients
plt.plot(range(len(col)), lasso_coef)
plt.xticks(range(len(col)), col, rotation=60)
plt.margins(0.02)
plt.show()

# =============================================================================
# Regularization II: Ridge
# =============================================================================
# Import necessary modules
from sklearn.linear_model import Ridge
from sklearn.model_selection import cross_val_score

# Setup the array of alphas and lists to store scores
alpha_space = np.logspace(-4, 0, 50)
ridge_scores = []
ridge_scores_std = []

# Create a ridge regressor: ridge
ridge = Ridge(normalize = True)

# Compute scores over range of alphas
for alpha in alpha_space:

    # Specify the alpha value to use: ridge.alpha
    ridge.alpha = alpha
    
    # Perform 10-fold CV: ridge_cv_scores
    ridge_cv_scores = cross_val_score(ridge, X, y, cv = 10)
    
    # Append the mean of ridge_cv_scores to ridge_scores
    ridge_scores.append(np.mean(ridge_cv_scores))
    
    # Append the std of ridge_cv_scores to ridge_scores_std
    ridge_scores_std.append(np.std(ridge_cv_scores))

# Display the plot
from matplotlib import pyplot as plt
def display_plot(cv_scores, cv_scores_std):
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    ax.plot(alpha_space, cv_scores)

    std_error = cv_scores_std / np.sqrt(10)

    ax.fill_between(alpha_space, cv_scores + std_error, cv_scores - std_error, alpha=0.2)
    ax.set_ylabel('CV Score +/- Std Error')
    ax.set_xlabel('Alpha')
    ax.axhline(np.max(cv_scores), linestyle='--', color='.5')
    ax.set_xlim([alpha_space[0], alpha_space[-1]])
    ax.set_xscale('log')
    plt.show()
display_plot(ridge_scores, ridge_scores_std)



# prediction_space = np.linspace(min(X_test[:,0]), max(X_test[:,0])).reshape(-1,1)
# about reshape:
# The new shape should be compatible with the original shape. If an integer, 
# then the result will be a 1-D array of that length.
# One shape dimension can be -1. In this case, 
# **the value is inferred from the length of the array and remaining dimensions**

