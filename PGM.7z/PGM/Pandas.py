# -*- coding: utf-8 -*-
"""
Created on Mon May 25 11:44:09 2020

@author: Daisy Chan
"""

# =============================================================================
# Pandas
# pandas is a fast, powerful, flexible and easy to use open source data analysis 
# and manipulation tool, built on top of the Python programming language.
# =============================================================================
import pandas as pd

# The DataFrame is one of Pandas' most important data structures. 
# It's basically a way to store tabular data where you can label the rows 
# and the columns. One way to build a DataFrame is from a dictionary.
test = {'a':[1,2,3,4,5],'b':[9,8,7,6,5]}
test_df1 = pd.DataFrame(test)
test_df2 = pd.DataFrame.from_dict(test, orient = 'columns')

# Note: if you pass an scalar to this method, there will be an error
europe = {'spain': 'madrid', 'france': 'paris', 'germany': 'berlin', 'norway': 'oslo'}
europe_df = pd.DataFrame(europe)
europe_df = pd.DataFrame(europe,index=[0])

# read data from csv file
PCDC = pd.read_csv(r'G:\Personal\My_Python\DataSet\Provisional_COVID-19_Death_Counts_by_Place_of_Death_and_State.csv')
titanic = pd.read_csv(r'G:\Personal\My_Python\DataSet\train.csv')

# To better understand DataFrame objects, it's useful to know that they consist 
# of three components, stored as attributes:
#.values: A two-dimensional NumPy array of values.
#.columns: An index of columns: the column names.
#.index: An index for the rows: either row numbers or row names.
PCDC.columns
titanic.columns
PCDC.index
titanic.index
PCDC.values
titanic.values

# Index info
PCDC.index

# statistical describe 
PCDC.describe()

# =============================================================================
# Subset and Slicing
# =============================================================================
# You can index and select Pandas DataFrames in many different ways. 
# The simplest, but not the most powerful way, is to use square brackets.
# The single bracket version gives a Pandas Series, 
# the double bracket version gives a Pandas DataFrame.
# Series: One-dimensional ndarray with axis labels (including time series).
PCDC[0:50]
type(PCDC[0:50])
PCDC['Place of Death']
PCDC[['Place of Death']]
type(PCDC['Place of Death'])
type(PCDC[['Place of Death']])
PCDC['Place of Death'].describe()

# With loc and iloc you can do practically any data selection operation 
# on DataFrames you can think of. 
# pd.DataFrame.iloc: index based
PCDC.iloc[0]
PCDC.iloc[0:3]
PCDC.iloc[:, 0:3]
PCDC.iloc[0:3,0:3]

# pd.DataFrame.loc: label based
# reset its index:
test = titanic.set_index('PassengerId')
test.loc[1:3]
test.loc[    :    ,    ['Survived','Cabin']]

# comparision and filtering
PCDC[PCDC['State']>='Michigan']
PCDC['State'][PCDC['State']>='Michigan']
PCDC[PCDC['State'].isin(['Oklahoma', 'Oregon', 'Pennsylvania'])]




# =============================================================================
# Pandas: Data manipulation
# =============================================================================
# Transformation
# update a DataFrame/change values
# 1. adding new columns
PCDC['COVID19 Deaths ratio'] = PCDC['COVID19 Deaths']/ PCDC['Total Deaths']
PCDC['Pneumonia Deaths ratio'] = PCDC['Pneumonia Deaths']/ PCDC['Total Deaths']
PCDC['Influenza Deaths ratio'] = PCDC['Influenza Deaths']/ PCDC['Total Deaths']
# delete row/column
# PCDC.DataFrame.drop([index/columns list])
# copy

# for Series, we do update/modify/filtering 

# sort rows
# if you want to change the order of the rows. You can sort the rows by 
# passing a column name to .sort_values()
PCDC.sort_values('State')
PCDC_new = PCDC.sort_values('State')
pd.DataFrame.sort_index(level = )

# Aggregating Data:pd.DataFrame.columns.function()
# mean, median, std, max, min
PCDC['COVID19 Deaths ratio'].mean()
PCDC['COVID19 Deaths ratio'].median()
PCDC['Total Deaths'].std()
PCDC['Total Deaths'].max()
PCDC['Total Deaths'].min()

# Count non-NA cells for each column or row.
# The values `None`, `NaN`, `NaT`, and optionally `numpy.inf` (depending
# on `pandas.options.mode.use_inf_as_na`) are considered NA.
PCDC['Pneumonia, Influenza, or COVID19 Deaths'].count()
PCDC.count(axis = 'columns')

# In the custom function for this exercise, "IQR" is short for 
# inter-quartile range, which is the 75th percentile minus the 25th percentile. 
# It's an alternative to standard deviation that is helpful if your data contains outliers.
def iqr(column):
    return column.quantile(0.75) - column.quantile(0.25)

#.agg() method allows you to apply your own custom functions to a DataFrame, 
# as well as apply functions to more than one column of a DataFrame at once, 
# making your aggregations super efficient.
import numpy as np
PCDC[['COVID19 Deaths ratio', 'Pneumonia Deaths ratio', 'Influenza Deaths ratio']].agg([iqr, np.median])

# Cumulative statistics can also be helpful in tracking summary statistics over time.
# pd.DataFrame.columns_name.cumsum()
# pd.DataFrame.columns_name.cummax()

# drop duplicates
pd.DataFrame.drop_duplicates()
temperature = pd.read_csv(r'G:\Personal\My_Python\DataSet\test_2.csv')
temperature_2 = test_2.set_index('Month')
temperature = pd.read_csv(r'G:\Personal\My_Python\DataSet\test_2.csv', parse_dates = True, index_col='Month')
temperature.drop_duplicates(['Max_TemperatureC', 'Min_TemperatureC'])

# groupby method
import numpy as np
PCDC_sum_by_state = PCDC.groupby('State').agg([np.min,np.max, np.mean, np.median])

# Pivot table
pd.DataFrame.pivot_table()
PCDC_pivot = PCDC.pivot_table(values = 'COVID19 Deaths', index = 'State')

# Slicing and indexing
test.reset_index()
# pd.DataFrame.set_inde(index_list/index column)
# pd.DataFrame.sort_index()

# Creating and Visualizing DataFrames
pd.DataFrame.plot()
pd.plot_type(pd.DataFrame,...)

# =============================================================================
# Pandas: Data Cleaning
# =============================================================================
# Finding Missing Data
# Nan||None||NaT||Null
# Nan: Not a Number, NaN是numpy\pandas下的，不是Python原生的.
# None: None不同于空列表和空字符串，是一种单独的格式
# NaT: Not a Time, 该值可以存储在 datetime 数组中以指示未知或缺失的 datetime 值。
# NaT 该值可以存储在 datetime 数组中以指示未知或缺失的 datetime 值,返回一个 (NaT) datetime 非时间标量值.
import numpy as np
type(np.NaN)
type(None)
type(np.nan)

pd.DataFrame.isna()
pd.DataFrame.isnull()
PCDC.isnull()
PCDC.isna().any()
PCDC.isna().count()

# =============================================================================
# List of dictionaries
# =============================================================================
# Create a list of dictionaries with new data
avocados_list = [
    {'date': "2019-11-03", 'small_sold': 10376832, 'large_sold': 7835071},
    {'date': "2019-11-10", 'small_sold': 10717154, 'large_sold': 8561348},
]

# Convert list into DataFrame
avocados_2019 = pd.DataFrame(avocados_list)

# Print the new DataFrame
print(avocados_2019)


# =============================================================================
# CSV to DataFrame & DataFrame to CSV
# =============================================================================
# pd.read_csv(dir, ...)
# pd.DataFrame.to_csv(dir)


# =============================================================================
# merging-dataframes-with-pandas
# =============================================================================
# Appending Series with nonunique Indices
pd.Series.append([])

# Appending DataFrame

# Merge, concat, join
# concat(): horizontally merge by default
# pd.concat(ibjs, axis = 0, join = 'outer', join_axes = None, ignore_index = False, 
#           keys = None, levels = None, names = None, verify_integrity = False, sort = None, copy = True,)

avocados_new = pd.concat([avocados_2018, avocados_2019], axis = 0)
avocados_new = pd.concat([avocados_2018, avocados_2019[['date','small_sold']]], axis = 0)
#avocados_new = pd.concat([avocados_2018, avocados_2019[['date','small_sold']]], axis = 0, join = 'inner')
avocados_new = pd.concat([avocados_2018[['date','small_sold']], avocados_2019[['date','small_sold']]], axis = 1) 

# rename(), set_names(), set_index(), reindex()
avocados_new.rename(columns = {'date':'Date'})
avocados_new.rename(index = {0:1,1:2})
avocados_new.set_index([])
avocados_new.set_index('date')
avocados_new.reindex()

# Merge: horizontally merge by default
# 两种写法都可以
pd.DataFrame.merge(right,how = 'inner', on = None, left_on = None, ... )
pd.merge(left, right,...)

left = pd.DataFrame({'account': ['K0', 'K1', 'K2', 'K3'],
                      'series':[1, 2, 3, 4]})
                       # 'age': ['27', '25', '23', '33'],
                       # 'gender': ['F', 'F','M', 'F']})

right = pd.DataFrame({'account': ['K0', 'K0', 'K2', 'K3'],
                      'series':[1, 2, 3, 4]})
                        # 'bill_amt': ['1200', '213', '1800', '800'],
                        # 'sign': ['+', '+', '-', '+']})
                      
    
left.merge(right, how = 'inner', left_on = 'account', right_on = 'account_')
# 当merge没有指定链接键时，默认从left和right列的交集将被推断为连接键
left.merge(right, how = 'right')
pd.merge(left, right, how = 'inner')
pd.merge(left, right, how = 'outer')
left.merge(right, how = 'outer')

# Perform merge with optional filling/interpolation.
# pd.merge_ordered(left, right, ...)

# .join(): vertically merge
# pd.DataFrame.join(self, other, on = None, how = 'left', lsuffix = '', sort = False)
# lsuffix: Suffix to use from left frame's overlapping columns.
# lsuffix: Suffix to use from right frame's overlapping columns.



