# -*- coding: utf-8 -*-
"""
Created on Tue Jun  2 17:59:30 2020

@author: Daisy Chan
"""
# =============================================================================
# String Format
# =============================================================================
# %s	字符串
# %d	有符号整数（十进制）
# %f	浮点数
# %O	转换为带符号的八进制形式的整数
# %X	转换为带符号的十六进制形式的整数
# %e	转换为科学计数法表示的浮点数（e小写）
# %c	格式化字符及其ASCII码

# 格式化字符串时，Python使用一个字符串作为模板。模板中有格式符，这些格式符为真实值预留位置，
# 并说明真实数值应该呈现的格式。Python用一个tuple将多个值传递给模板，每个值对应一个格式符。
print('Hello, today is %s, it\'s %s today.' % ('Monday', 'rainy'))

# 以上，'Hello, today is %s, it\'s %s today.' 为模板。%s为格式符，表示一个字符串。
# ('Monday', 'rainy')的两个元素为替换%s的真实值, 在模板和tuple之间，有一个%号分隔，它代表了格式化操作。

# 还可以 以字典形式传递真实值：
print("I'm %(name)s. I'm %(age)d year old" % {'name':'Danny', 'age':5})

#另外python还有一个更强大的字符串处理函数  str.format()
# 通过"{}"和"."来代替 %
# 一般用法：
'{},{}'.format('kzc',18) 
print("还有{}天放假，我还在坚持学习{}".format(2, "Python"))

# 通过位置
print("还有{1}天放假，我还在坚持学习{0}".format("Python", 2))
# 字符串的format函数可以接受不限个参数，位置可以不按顺序，可以不用或者用多次。
p = ['学Python','写论文']
q = ['放假','毕业']
print("还有1天{1[0]}，我还在{0[0]}".format(p, q))
print("还有1天{1[1]}，我还在{0[1]}".format(p, q))

# 通过关键字参数
print("还有{day}天放假，我还在坚持学习{str1}".format(str1 = "Python", day = 2))


# =============================================================================
# 通过对象属性
# class Person: 
#   def __init__(self,name,age): 
#     self.name,self.age = name,age 
#     def __str__(self): 
#       return 'This guy is {self.name},is {self.age} old'.format(self=self) 
# 
# str(Person('kzc',18)) 
# 
# p=['kzc',18]
# '{0[0]},{0[1]}'.format(p)
# =============================================================================



# =============================================================================
# re module
# This module provides regular expression matching operations similar to
# those found in Perl.  It supports both 8-bit and Unicode strings; both
# the pattern and the strings being processed can contain null bytes and
# characters outside the US ASCII range.
# =============================================================================
# a regular expression (abbreviated regex or regexp and sometimes called a rational expression) 
# is a sequence of characters that define a search pattern, mainly for use in pattern.
import re
?re
# re.match(pattern, string, flags = ...): 
# Match a regular expression pattern to the beginning of a string.
str1 = 'University of Birmingham'
ptn = 'University'
re.match(ptn, str1)
# return <re.Match object; span=(0, 10), match='University'>
# how do we dealing with this?
mth = re.match(ptn, str1)
if mth:
    print(mth.group()) #返回匹配的元素
    print(mth.start()) #返回开始位置
    print(mth.end()) #返回结束的位置
    print(mth.span()) #以元组形式返回开始结束的位置
    
# =============================================================================
# Regular expression operations
# 
# =============================================================================
# 1. Most ordinary characters, like 'A', 'a', or '0', are the simplest regular expressions;
#   they simply match themselves. You can concatenate ordinary characters, 
#  so last matches the string 'last'.

# 2. Some characters, like '|' or '(', are special. Special characters either stand for 
#  classes of ordinary characters, or affect how the regular expressions around them are interpreted 
    
    # . (Dot.) In the default mode, this matches any character except a newline. 
    # If the DOTALL flag has been specified, this matches any character including a newline.
str0 = 'abc\nd'
re.match('.', str0, flags = 0)
str1 = '\nabcd'
re.match('.', str1, flags = 0)

    # ^ (Caret.) Matches the start of the string, and in MULTILINE mode also matches immediately after each newline.
str0 = 'aba\na'
re.match('^a', str0, flags = 0)
str1 = '\nabcd'
re.match('^a', str1, flags = 0)

    # $: Matches the end of the string or just before the newline at the end of the string, 
    # and in MULTILINE mode also matches before a newline
str0 = 'foobar\n'
re.match('foo$', str0, flags = 0)
str0 = 'foo\n'
re.match('foo$', str0, flags = 0)
str1 = 'foo\nfoo2'
re.match('foo2$', str1, flags = 0)

    # {m}: Specifies that exactly m copies of the previous RE should be matched; 
    # fewer matches cause the entire RE not to match.
str0 = 'fooofo'
re.match('o{3}', str0, flags = 0)
str1 = 'fooofo'
re.match('o{3}', str1, flags = 0)

    # {m,n}: Causes the resulting RE to match from m to n repetitions of the preceding RE, 
    # attempting to match as many repetitions as possible. 
    # For example, a{3,5} will match from 3 to 5 'a' characters.  
    # {m,n}?: Causes the resulting RE to match from m to n repetitions of the preceding RE, 
    # attempting to match as few repetitions as possible. 
    # This is the non-greedy version of the previous qualifier. 
    # For example, on the 6-character string 'aaaaaa', a{3,5}? will only match 3 characters.
str0 = 'aaaaaa'
re.match('a{3,5}', str0, flags = 0)
re.match('a{3,5}?', str0, flags = 0)

    # \: Either escapes special characters (permitting you to match characters like '*', '?', 
    # and so forth), or signals a special sequence; special sequences are discussed below.
    # If you’re not using a raw string to express the pattern, remember that Python also uses the backslash
    # as an escape sequence in string literals; if the escape sequence isn’t recognized by Python’s parser,
    # the backslash and subsequent character are included in the resulting string. However, 
    # if Python would recognize the resulting sequence, the backslash should be repeated twice. 
    # This is complicated and hard to understand, so it’s highly recommended that you use raw strings 
    # for all but the simplest expressions..
str0 = '\nhello'
re.match('\nh', str0, flags=0)
str1 = '\\nhello'
re.match('\\\\nh', str1, flags = 0)    
    
    # |: A|B, where A and B can be arbitrary REs, creates a regular expression that will match either A or B. 
    # A arbitrary number of REs can be separated by the '|' in this way. This can be used inside groups (see below) as well. 
    # As the target string is scanned, REs separated by '|' are tried from left to right. 
    # When one pattern completely matches, that branch is accepted. This means that once A matches,
    # B will not be tested further, even if it would produce a longer overall match. 
    # In other words, the '|' operator is never greedy. To match a literal '|', use \|, 
    # or enclose it inside a character class, as in [|].
    
    
    # For example, on the 6-character string 'aaaaaa', a{3,5}? will only match 3 characters.
    # For example, on the 6-character string 'aaaaaa', a{3,5}? will only match 3 characters.




