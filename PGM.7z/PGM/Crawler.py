# -*- coding: utf-8 -*-
"""
Created on Mon Jun  8 16:29:04 2020

@author: Daisy 
"""
# =============================================================================
# 爬虫流程：
# 通过HTTP库向目标站点发起请求（request), 请求可以包含额外的header等信息，等待服务器响应
# 请求方式GET, POST, DELETE, HEAD, OPTION等
# GET把请求参数包含在URL中;
# POST通过request body（Form data)传递参数;

# 如果服务器能正常响应，会得到一个response, 即站点的页面内容，类型可能是HTML, JSON, 二进制数据等
# 得到页面内容后，可用正则表达式网页解析库等进行解析
# 保存形式多样，可以存为文本，数据库等
# 
# 能抓取怎样的数据？
# 网页文本（HTML, Json)，视频(二进制），图片（二进制），其他
#
# 解析数据
# 直接处理，正则表达式，Json解析， BeautifulSoup, XPath, PyQuery, 
#
# 怎样保存数据
# 文本（纯文本，JSON, xml等
# 关系型数据库（MySQL, Oracle, SQL Server)
# 非关系型数据库MongoDB, Redis等Key-Value形式存储
#
#
# 1. 先对具体的URL进行请求，得到response（网页源码）
# 2. 对response进行解析，提取所需数据
# 3. 整理数据，以文本或二进制存储到对应路径/数据库
#
# =============================================================================
# URL(Uniform Resource Locator): 全球资源定位器, 也就是我们俗称的网址
# HTML(Hyper Text Markup Language): HTML是用来标记Web信息如何展示以及其他特性的一种语法规则.
# 爬虫第一步，就是获取网页的HTML信息.

# 1.urllib.request 负责请求
# 2. urllib.error 异常处理模块
# 3. urllib.parse url 负责解析页面内容（response)
# 4. urllib.robotparser 负责robots.txt文件的解析

import urllib
url_2 = 'https://www.77mh.net/colist_244254.html'

# Step_1:发起一个请求
# urllib.request.urlopen 返回一个类文件对象
# response = urllib.request.urlopen(url)
response = urllib.request.urlopen(url_2)

# pass the url and optionally data to post to an HTTP URL, and get a file-like object back. 
# urllib.request.urlopen(url, data=None, [timeout, ]*, cafile=None, capath=None, 
#                        cadefault=False, context=None)
# url: 链接
# data: Post提交的数据, 默认为None
# timeout: 设置网站的访问超过时间

#-  read() , readline() ,readlines() , fileno() , close() ：对HTTPResponse类型数据进行操作
#
#-  info()：返回HTTPMessage对象，表示远程服务器返回的头信息
#
#-  getcode()：返回Http状态码。如果是http请求，200请求成功完成 ; 404网址未找到
#
#-  geturl()：返回请求的url

#try:
#    urllib.request.urlopen(url_2)
#except urllib.error.HTTPError as err:
#    print(err)

#网站有反爬虫机制？尝试模拟人工点击打开网页
# header = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
# request = urllib.request.Request(url_2, headers = header)  
# response = urllib.request.urlopen(request)
# html = response.read()
# print(html)
html = response.read()
print(html)

# Step_2： 解析html内容，提取需要的数据.
# pip intall -e dir
# python C:\Users\Chengcen\Anaconda3\Tools\scripts\2to3.py -w C:\Users\Chengcen\Anaconda3\Lib\beautifulsoup4
from bs4 import BeautifulSoup
soup = BeautifulSoup(html)
#import chardet
# 作为一个BeautifulSoup对象，soup是由html转换成的一个复杂的树形结构,每个节点都是Python对象,
# 所有对象可以归纳为4种: Tag , NavigableString , BeautifulSoup , Comment .
# 1. Tag 对象与XML或HTML原生文档中的tag相同;
#      Tag有很多方法和属性,在 遍历文档树 和 搜索文档树 中有详细解释.
#     现在介绍一下tag中最重要的属性: name和attributes
#   soup.tag.name
#   soup.tag.attrs
par = soup.find('ul', class_ = 'ar_rlos_bor ar_list_col').find_all('a')
link_new = []
parent = 'https://www.77mh.net'
for i in range(len(par)):
    link_new.append(parent + str(par[i]['href']))
link_new.sort()

import urllib
def Get_html(url):
    response = urllib.request.urlopen(url)
    html = response.read()
    return html

def Get_html2(url, header):
    request = urllib.request.Request(url, headers = header)
    response = urllib.request.urlopen(request)
    html = response.read()
    return html

from bs4 import BeautifulSoup
def Get_soup(html):
    soup = BeautifulSoup(html)

import requests
response = requests.get('https://tse2-mm.cn.bing.net/th/id/OIP.1HwdrT8NWPmK4TM16zpfOgHaE8?pid=Api&rs=1')
with open(r'C:\Users\Daisy Chan\Downloads\1.jpeg', 'wb') as f:
    f.write(response.content)

# with 语句是从 Python 2.5 开始引入的一种与异常处理相关的功能（2.5 版本中要通过 
# from __future__ import with_statement 导入后才可以使用），
# 从 2.6 版本开始缺省可用（参考 What's new in Python 2.6? 中 with 语句相关部分介绍）。
# with 语句适用于对资源进行访问的场合，确保不管使用过程中是否发生异常都会执行必要的“清理”
# 操作，释放资源，比如文件使用后自动关闭、线程中锁的自动获取和释放等。


# 如何处理JavaScript渲染的问题？
# 分析Ajax请求，Selenium/WebDriver,Splash,PyV8, Ghost.py

