# -*- coding: utf-8 -*-
"""
Created on Mon May 25 10:04:50 2020

@author: Daisy Chan
"""

# =============================================================================
# Variable type
# int/integer, float, str/string, bool(sub-object of int), list, dict, tuple
# 不可变数据类型： 当该数据类型的对应变量的值发生了改变，那么它对应的内存地址也会发生改变，
# 对于这种数据类型，就称不可变数据类型。
# 可变数据类型 ：当该数据类型的对应变量的值发生了改变，那么它对应的内存地址不发生改变，
# 对于这种数据类型，就称可变数据类型。
# string, bytes(在Python 3之后bytes类型和string类型彻底分开了), tuple都是不可辨数据类型
# =============================================================================
# Definition of savings and result
savings = 100
result = 100 * 1.10 ** 7

# Fix the printout
print("I started with $" + str(savings) + " and now have $" + str(result) + ". Awesome!")

# Definition of pi_string
pi_string = "3.1415926"

# Convert pi_string into float: pi_float
pi_float = float(pi_string)


# =============================================================================
# list: a compound data type; you can group values together
# A list can contain any Python type. But a list itself is also a Python type. 
# That means that a list can also contain a list! 
# =============================================================================
# empty list
el = []

# Create the areas list
areas = ["hallway", 11.25, "kitchen", 18.0, "living room", 20.0, "bedroom", 10.75, "bathroom", 9.50]

# Print out second element from areas
print(areas[1])

# Print out last element from areas
print(areas[-1])

# Alternative slicing to create downstairs
downstairs = areas[:6]

# Alternative slicing to create upstairs
upstairs = areas[-4:]

# Subsetting lists of lists
x = [["a", "b", "c"],
     ["d", "e", "f"],
     ["g", "h", "i"]]
x[2][0]
x[2][:2]

# manipulating list

#Change the value which in the 9th position
areas[9] = 10.50

# Change "living room" to "chill zone"
areas[areas.index("living room")] = "chill zone"

# Add poolhouse data to areas, new list is areas_1
areas_1 = areas+ ["poolhouse", 24.5]

# Add garage data to areas_1, new list is areas_2
areas_2 = areas_1 + ["garage"] + [15.45]

# Append a new element at the end of position
areas.append('piano room')

# Insert a new element at the specific position
areas.insert(2, 'dining room')

# Delete list elements
x = ["a",  "c", "b", "d"]
del(x[1])

# Copy a list
y = x
y[0] = 1
print(y)
print(x)

y=
TBC...
# get the index of 'a' in x
index_a = x.index('a')

# sort a list:
# sort() 是Python列表的一个内置的排序方法，list.sort() 方法排序时直接修改原列表，返回None；
# sorted() 是Python内置的一个排序函数，它会从一个迭代器返回一个排好序的新列表。
x.sort()
print(x)
sorted(x)
# =============================================================================
# Dictionary is a mutable container model and can store objects of any type.
# 注意：字典中的Entry是无序的
# 注意：遍历字典的时候，与你添加元素的顺序、访问元素的顺序均无关，当你遍历字典的时候，
# 如果恰巧与你添加的元素的顺序是一样的，仅仅是巧合而已，需要有序字典请看OrderDict
# =============================================================================

# Create a dict from two lists:
# Definition of countries and capital
countries = ['spain', 'france', 'germany', 'norway']
capitals = ['madrid', 'paris', 'berlin', 'oslo']

# create dict europe:
europe = {}
for country in countries:
    for city in capitals:
        if capitals.index(city) == countries.index(country):
            europe[country] = city
        


# create a dict directly indicate a specific key posion:
dict1 = {'a':1}
dict1['b'] = 2

# cannot indicate a specific position
dict2['a'] = 1

# create a dict by using update method:
dict1.update({'c':3, 'd':4, 'e':5})

# Delete operation

del dict1['a']  # 删除键是'Name'的条目
del(dict1['a'])

dict1.clear()      # 清空字典所有条目
del dict1          # 删除字典
del(dict1) 

#for del's more details, see del.pdf

#sort dict
print(europe)
print(sorted(europe))
print(sorted(europe.values()))




# =============================================================================
# Logic, Control Flow and Loops: if, for/while
# =============================================================================
   
# if condition:
#     expression 

# if condition1:
#     expression1
# else:
#     expression2

# if condition1:
#     expression1
# elif condition2:
#     expression2
# elif condition3:
#     expression3
# ...
# else:
#     do


# while condition :
#     expression

# for items in iterable:
#     expression

